﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace _9
{
    internal class Student
    {
        public string Name {  get; set; }
        public string Last_name { get; set; }
        public string Patronymic { get; set; }
        public string Group_num { get; set; }
        public int[] Evaluations { get; set; }

        public Student(string name, string last_name, string patronymic, string group_num, int[] evaluations)
        {
            this.Name = name;
            this.Last_name = last_name;
            this.Patronymic = patronymic;
            this.Group_num = group_num;
            this.Evaluations = evaluations;
        }
    }
}
