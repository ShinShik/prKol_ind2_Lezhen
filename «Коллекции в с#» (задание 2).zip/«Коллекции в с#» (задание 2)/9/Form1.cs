﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace _9
{
    public partial class Form1 : Form
    {
        Queue<Student> MyQueue = new Queue<Student>();        
        public Form1()
        {
            InitializeComponent();
            StreamReader sr = File.OpenText("txt.txt");
            while (!sr.EndOfStream)
            {
                string[] line = sr.ReadLine().Split();
                int[] evaluations = new int[3];
                evaluations[0] = int.Parse(line[4]); evaluations[1] = int.Parse(line[5]); evaluations[2] = int.Parse(line[6]);
                MyQueue.Enqueue(new Student(line[0], line[1], line[2], line[3], evaluations));
            }
            sr.Close();            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            var nn = from n in MyQueue
                     where n.Evaluations[0] != 2 && n.Evaluations[1] != 2 && n.Evaluations[2] != 2
                     select n;
            var nnn = from n in MyQueue
                      where n.Evaluations[0] == 2 || n.Evaluations[1] == 2 || n.Evaluations[2] == 2
                      select n;
            foreach (Student st in nn)
            {
                listBox1.Items.Add($"{st.Last_name} {st.Name} {st.Patronymic} {st.Group_num} {st.Evaluations[0]}, {st.Evaluations[1]}, {st.Evaluations[2]}");
            }
            foreach (Student st in nnn)
            {
                listBox1.Items.Add($"{st.Last_name} {st.Name} {st.Patronymic} {st.Group_num} {st.Evaluations[0]}, {st.Evaluations[1]}, {st.Evaluations[2]}");
            }
        }
    }
}
