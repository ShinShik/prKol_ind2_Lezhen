﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Collections;

namespace _Коллекции_в_с____задание_2_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Stack lines = new Stack();
            StreamReader sr = File.OpenText("t.txt");
            string line;
            while (!sr.EndOfStream)
            {
                line = sr.ReadLine();
                var str = from c in line
                          where char.IsLetter(c)
                          select c;
                line = "";
                foreach (var c in str) 
                {
                    line += c;
                }
                lines.Push(line);                
            }
            foreach (string lin in lines)
            {
                string reversedLine = new string(lin.Reverse().ToArray());
                Console.WriteLine(reversedLine);
            }
            Console.ReadLine();
        }
    }    
}
